---
title: Документы
---

<h1>Документы</h1>
<div d1ta-featherlight-gallery d1ta-featherlight-filter="a">
    <div class="docs-items">
	    <div class="docs-item">
	      <a href="docs/license-medic.pdf" target="_blank">
	        <img width=150 height=210 src="docs/license-medic-thumb.jpg" />
	        <p>Лицензия на оказание медицинских услуг</p>
	      </a>
	    </div>
		<div class="docs-item">
		  <a href="docs/certificate-living.pdf" target="_blank">
		    <img width=150 height=210 src="docs/certificate-living-thumb.jpg" />
		    <p>Сертификат соответствия услуг проживания</p>
		  </a>
		</div>
		<div class="docs-item">
		  <a href="docs/certificate-food.pdf" target="_blank">
		    <img width=150 height=210 src="docs/certificate-food-thumb.jpg" />
		    <p>Сертификат соответствия услуг питания</p>
		  </a>
		</div>
  	</div>
</div>