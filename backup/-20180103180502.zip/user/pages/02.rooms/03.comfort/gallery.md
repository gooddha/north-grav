---
title: Номера категории "Комфорт"
menu: Комфорт
---

# Номера категории "Комфорт"

## Однокомнатный двухместный
<div data-featherlight-gallery data-featherlight-filter="a">
    <a href="comfort/1-1.jpg"> <img width=150 height=150 src="comfort/thumbs/1-1.jpg" /></a>
    <a href="comfort/1-2.jpg"> <img width=150 height=150 src="comfort/thumbs/1-2.jpg" /></a>
    <a href="comfort/1-3.jpg"> <img width=150 height=150 src="comfort/thumbs/1-3.jpg" /></a>
    <a href="comfort/1-4.jpg"> <img width=150 height=150 src="comfort/thumbs/1-4.jpg" /></a>
</div>
Номера этой категории выполнены в приятных светлых тонах. В номерах двуспальная кровать, прикроватные тумбочки, телевизор, холодильник, микроволновая печь и электрический чайник, а также раскладное кресло, которое можно использовать в качестве дополнительного спального места. В ванной комнате есть душевая кабина, туалет и раковина.

## Двухкомнатный двухместный
<div data-featherlight-gallery data-featherlight-filter="a">
    <a href="comfort/2-1.jpg"> <img width=150 height=150 src="comfort/thumbs/2-1.jpg" /></a>
    <a href="comfort/2-2.jpg"> <img width=150 height=150 src="comfort/thumbs/2-2.jpg" /></a>
    <a href="comfort/2-3.jpg"> <img width=150 height=150 src="comfort/thumbs/2-3.jpg" /></a>
    <a href="comfort/2-4.jpg"> <img width=150 height=150 src="comfort/thumbs/2-4.jpg" /></a>
    <a href="comfort/2-5.jpg"> <img width=150 height=150 src="comfort/thumbs/2-5.jpg" /></a>
    <a href="comfort/2-6.jpg"> <img width=150 height=150 src="comfort/thumbs/2-6.jpg" /></a>
    <a href="comfort/2-7.jpg"> <img width=150 height=150 src="comfort/thumbs/2-7.jpg" /></a>
    <a href="comfort/2-8.jpg"> <img width=150 height=150 src="comfort/thumbs/2-8.jpg" /></a>
</div>
Это номер для двоих, который состоит из гостиной и спальни. Первая оформлена раскладывающимся диваном, который с легкостью может стать спальным ложе для двух людей. Также есть стулья и стол. В спальне – платяной шкаф, две односпальные кровати и тумбочки. В номере можно пользоваться электрическим чайником, утюгом, телевизором. А в особо жаркую погоду пользоваться кондиционером. Апартаменты оснащены балконом и собственной ванной комнатой.
