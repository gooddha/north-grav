---
title: Reset password

form:
    fields:
        - name: username
          type: text
          placeholder: PLUGIN_ADMIN.USERNAME
          readonly: true
        - name: password
          type: password
          placeholder: PLUGIN_ADMIN.PASSWORD
          autofocus: true
        - name: token
          type: hidden
---
